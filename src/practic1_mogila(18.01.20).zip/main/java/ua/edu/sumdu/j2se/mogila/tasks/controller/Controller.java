package ua.edu.sumdu.j2se.mogila.tasks.controller;

import ua.edu.sumdu.j2se.mogila.tasks.Task;
import ua.edu.sumdu.j2se.mogila.tasks.model.Model;
import ua.edu.sumdu.j2se.mogila.tasks.view.View;


public class Controller implements ControllerInterface {

    private Model model;
    private View view;

    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    @Override
    public void addNewTask() {
        Task task = new Task();
        task.setTitle(view.readTitleFromLine());
        if (view.readTaskForm()) {
            task.setStart(view.readStartTimeFromLine());
            task.setEnd(view.readEndTimeFromLine());
            task.setInterval(view.readInterval());
        } else {
            task.setTime(view.readTimeFromLine());
        }
        task.setActive(true);
        model.add(task);
        view.Success();
    }

    @Override
    public void deleteTask() {
        if (listIsEmpty()) System.out.println("Список пуст!");
        else {
        if (model.delete(view.deleteTaskView())) {
            view.Success();
            model.save();
        }
        else view.deleteFail();
        }
    }

    @Override
    public void editTask() {
        if (listIsEmpty()) System.out.println("Список пуст!");
        else {
        Task task = new Task();
        task.setTitle(view.readTitleFromLine());
        if (view.readTaskForm()) {
            task.setStart(view.readStartTimeFromLine());
            task.setEnd(view.readEndTimeFromLine());
            task.setInterval(view.readInterval());
        }
        else {
            task.setTime(view.readTimeFromLine());
        }
            view.readTaskActive();
            model.edit(view.editTaskView(model),task);
        }
    }

    @Override
    public void infoOfTask() {
        if (listIsEmpty()) System.out.println("Список пуст!");
        else
        view.infoOfTaskView(model);
    }

    @Override
    public void calendarTask() {
        if (listIsEmpty()) System.out.println("Список пуст!");
        else
        view.calendarTaskView(model);
    }

    @Override
    public void act() {
        switch (view.mainMenu()) {
            case 0: System.exit(0);
            case 1: addNewTask(); break;
            case 2: infoOfTask(); break;
            case 3: deleteTask(); break;
            case 4: listOfTask(); break;
            case 5: editTask(); break;
            case 6: calendarTask(); break;

            default: view.noCommandPrint();
        }
    }

    @Override
    public void listOfTask() {
        if (listIsEmpty()) System.out.println("Список пуст!");
        else
        view.printList(model);
    }

    @Override
    public void startProgram() {
        model.openFile();
        view.printTaskNextWeek(model);
        view.notificationThread(model);
    }

    @Override
    public boolean listIsEmpty() {
        return model.getTaskList().size() == 0;
    }
}
