package ua.edu.sumdu.j2se.mogila.tasks;

import java.util.function.Supplier;

public class ListTypes {

    public enum types {
        ARRAY ,
        LINKED }
}
