package ua.edu.sumdu.j2se.mogila.tasks.view;

import ua.edu.sumdu.j2se.mogila.tasks.Task;
import ua.edu.sumdu.j2se.mogila.tasks.model.Model;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.SortedMap;

public interface ViewInterface {

    int mainMenu() throws IOException;

    void printList(Model model);

    void printInfo(Model model, int index);

    void printTaskNextWeek(Model model);

    void notificationThread(Model model);

    SortedMap<LocalDateTime, Set<Task>> calendar(Model model);

    String deleteTaskView();

    int editTaskView(Model model);

    void noCommandPrint();

    void Success();

    void deleteFail();

    void calendarTaskView(Model model);

    void infoOfTaskView(Model model);

    String readTitleFromLine();

    boolean readTaskForm();

    LocalDateTime readStartTimeFromLine();

    LocalDateTime readEndTimeFromLine();

    LocalDateTime readTimeFromLine() throws IOException;

    int readInterval();

    boolean readTaskActive();

}
